package com.connecture.bigbear.ancillary.model;

public class Coverage {
	private String coPay;
	private String frames;
	private String lenses;
	private String veneers;
	private String xrays;
	public String getCoPay() {
		return coPay;
	}
	public void setCoPay(String coPay) {
		this.coPay = coPay;
	}
	public String getFrames() {
		return frames;
	}
	public void setFrames(String frames) {
		this.frames = frames;
	}
	public String getLenses() {
		return lenses;
	}
	public void setLenses(String lenses) {
		this.lenses = lenses;
	}
	 
	public String getVeneers() {
		return veneers;
	}
	public void setVeneers(String veneers) {
		this.veneers = veneers;
	}
	public String getXrays() {
		return xrays;
	}
	public void setXrays(String xrays) {
		this.xrays = xrays;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[Copay:").append(coPay).append(";")
			.append("Frames:").append(frames).append(";")
			.append("Lenses:").append(lenses).append(";").append("]");
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Coverage)){
			return false;
		}
		Coverage c=(Coverage)obj;
		boolean isEqual = this.coPay.equals(c.getCoPay());
		isEqual = isEqual && this.frames.equals(c.getFrames());
		isEqual = isEqual && this.lenses.equals(c.getLenses());
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31; 
		int defaultValue="".hashCode();
		r *= (this.coPay==null?defaultValue:this.coPay.hashCode());
		r *= (this.frames==null?defaultValue:this.frames.hashCode());
		r *= (this.lenses==null?defaultValue:this.lenses.hashCode());
		return r;
	}
}
