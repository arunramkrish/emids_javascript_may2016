package com.connecture.bigbear.ancillary.model;

public class PlanDetail {
	private String id;
	private String title;
	private String deductible;
	private Coverage coverage;
	private Eligibility eligibility;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDeductible() {
		return deductible;
	}
	public void setDeductible(String deductible) {
		this.deductible = deductible;
	}
	public Coverage getCoverage() {
		return coverage;
	}
	public void setCoverage(Coverage coverage) {
		this.coverage = coverage;
	}
	public Eligibility getEligibility() {
		return eligibility;
	}
	public void setEligibility(Eligibility eligibility) {
		this.eligibility = eligibility;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[ID:").append(id).append(";")
		.append("Title:").append(title).append(";")
		.append("Deductible:").append(deductible).append(";")
		.append("Coverage:").append(coverage).append(";")
		.append("Eligibility:").append(eligibility).append(";").append("]"); 
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof PlanDetail)){
			return false;
		}
		PlanDetail pd=(PlanDetail)obj;
		boolean isEqual = this.id.equals(pd.getId());
		isEqual = isEqual && this.title.equals(pd.getTitle());
		/*isEqual = isEqual && this.deductible.equals(pd.getDeductible());
		isEqual = isEqual && this.coverage.equals(pd.getCoverage());
		isEqual = isEqual && this.eligibility.equals(pd.getEligibility());*/
		 
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31;
		int defaultValue = "".hashCode();
		r *= (this.id==null?defaultValue:this.id.hashCode());
		r *= (this.title==null?defaultValue:this.title.hashCode());
		r *= (this.deductible==null?defaultValue:this.deductible.hashCode());
		r *= (this.coverage==null?defaultValue:this.coverage.hashCode());
		r *= (this.eligibility==null?defaultValue:this.eligibility.hashCode());
		return r;
	}
}
