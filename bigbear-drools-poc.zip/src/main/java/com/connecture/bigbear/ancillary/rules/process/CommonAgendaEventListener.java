package com.connecture.bigbear.ancillary.rules.process;

import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.AgendaEventListener;
import org.kie.api.event.rule.AgendaGroupPoppedEvent;
import org.kie.api.event.rule.AgendaGroupPushedEvent;
import org.kie.api.event.rule.BeforeMatchFiredEvent;
import org.kie.api.event.rule.MatchCancelledEvent;
import org.kie.api.event.rule.MatchCreatedEvent;
import org.kie.api.event.rule.RuleFlowGroupActivatedEvent;
import org.kie.api.event.rule.RuleFlowGroupDeactivatedEvent;

import com.connecture.bigbear.ancillary.util.LogUtil;

public class CommonAgendaEventListener implements AgendaEventListener  {
	 
	public void matchCreated(MatchCreatedEvent event) { 
		LogUtil.logInfo("matchCreated::"+event.getMatch().getRule().getName());	 
	}

	public void matchCancelled(MatchCancelledEvent event) { 
		LogUtil.logInfo("matchCancelled:"+event.getMatch().getRule().getName());
	}

	public void beforeMatchFired(BeforeMatchFiredEvent event) { 
		LogUtil.logInfo("beforeMatchFired:"+event.getMatch().getRule().getName());
	}

	public void afterMatchFired(AfterMatchFiredEvent event) {
		LogUtil.logInfo("afterMatchFired:"+event.getMatch().getRule().getName()); 
	}

	public void agendaGroupPopped(AgendaGroupPoppedEvent event) {
		LogUtil.logInfo("agendaGroupPopped:"+event.getAgendaGroup().getName());
	}

	public void agendaGroupPushed(AgendaGroupPushedEvent event) {
		LogUtil.logInfo("agendaGroupPushed:"+event.getAgendaGroup().getName());  
	}

	public void beforeRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
		LogUtil.logInfo("beforeRuleFlowGroupActivated:"+event.getRuleFlowGroup().getName()); 
	}

	public void afterRuleFlowGroupActivated(RuleFlowGroupActivatedEvent event) {
		LogUtil.logInfo("afterRuleFlowGroupActivated:"+event.getRuleFlowGroup().getName()); 
	}

	public void beforeRuleFlowGroupDeactivated(
			RuleFlowGroupDeactivatedEvent event) { 
		LogUtil.logInfo("beforeRuleFlowGroupDeactivated:"+event.getRuleFlowGroup().getName());
	}

	public void afterRuleFlowGroupDeactivated(
			RuleFlowGroupDeactivatedEvent event) {
		LogUtil.logInfo("afterRuleFlowGroupDeactivated:"+event.getRuleFlowGroup().getName()); 
	}

}
