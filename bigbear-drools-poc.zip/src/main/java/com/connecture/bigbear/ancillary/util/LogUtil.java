package com.connecture.bigbear.ancillary.util;

import java.util.Iterator;
import java.util.Set;

public class LogUtil {
	private static final String newLine = System.lineSeparator();
	private static final String tab = "\t"; 
	private static LogHandler log = LogHandler.get(LogUtil.class);
	
	public static void logInfo(String msg){
		msg = msg.replaceAll("<",newLine+tab);
		msg = msg.replaceAll(">",newLine);
		msg = msg.replaceAll(";",tab); 
		log.info(msg); 
	}
	
	public static  void print (Set<?> el){
		 for (Iterator<?> iterator = el.iterator(); iterator.hasNext();) {
			 String msg = iterator.next().toString(); 
			log.view( msg); 
		}
	 } 
	 
}
