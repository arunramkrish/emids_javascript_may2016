package com.connecture.bigbear.ancillary.constants;

public enum Health {
 Rare,Regular,Significant
}
