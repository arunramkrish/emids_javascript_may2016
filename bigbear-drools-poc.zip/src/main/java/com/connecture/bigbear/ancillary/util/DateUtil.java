package com.connecture.bigbear.ancillary.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	  
	public static int getAge(Date dob) {
		int age=0; 
	    Calendar calDob=Calendar.getInstance();
	    calDob.setTime(dob); 
	    Calendar now=Calendar.getInstance();
	    now.setTime(new Date());  
	    age=now.get(Calendar.YEAR) - calDob.get(Calendar.YEAR); 
	    calDob.add(Calendar.YEAR, age);        
	    if (now.before(calDob)) {
	        age--;
	    } 
		return age;
	} 
}
