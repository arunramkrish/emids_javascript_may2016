package com.connecture.bigbear.ancillary.model;

public class State {
	private String code;
	private String name;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[Code:").append(code).append(";")
		.append("Name:").append(name).append(";").append("]") ;
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof State)){
			return false;
		}
		State c=(State)obj;
		boolean isEqual = this.code.equals(c.getCode());
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31;
		r *= this.code.hashCode();
		r *= this.name.hashCode();
		
		return r;
	}  
}
