/**
 * 
 */
package com.connecture.bigbear.ancillary.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * @author GaneshV
 *
 */
public class Profile {
	private String zipCode;
	private Set<Member> members;
	private String eligibleForTax;
	private String recentLifeEvent;
	private Date recentLifeEventDate;
	private String medicalCoverageExists;
	private String planPreference;
	private String planAmountRange;
	private String specialistWithoutReference;
	private String preferHSA;
	private Set<Plan> recommendedPlans;
	
	
	public Profile(){
		zipCode="";
		members=new HashSet<Member>();
		recentLifeEvent="";
		recentLifeEventDate=new Date();
		medicalCoverageExists="";
		planPreference="";
		planAmountRange="";
		specialistWithoutReference="";
		preferHSA="";
		recommendedPlans=new HashSet<Plan>();
	}
	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Set<Member> getMembers() {
		return members;
	}

	public void setMembers(Set<Member> members) {
		this.members = members;
	}

	public String getEligibleForTax() {
		return eligibleForTax;
	}

	public void setEligibleForTax(String eligibleForTax) {
		this.eligibleForTax = eligibleForTax;
	}

	public String getRecentLifeEvent() {
		return recentLifeEvent;
	}

	public void setRecentLifeEvent(String recentLifeEvent) {
		this.recentLifeEvent = recentLifeEvent;
	}

	public Date getRecentLifeEventDate() {
		return recentLifeEventDate;
	}

	public void setRecentLifeEventDate(Date recentLifeEventDate) {
		this.recentLifeEventDate = recentLifeEventDate;
	}

	public String getMedicalCoverageExists() {
		return medicalCoverageExists;
	}

	public void setMedicalCoverageExists(String medicalCoverageExists) {
		this.medicalCoverageExists = medicalCoverageExists;
	}

	public String getPlanPreference() {
		return planPreference;
	}

	public void setPlanPreference(String planPreference) {
		this.planPreference = planPreference;
	}

	public String getPlanAmountRange() {
		return planAmountRange;
	}

	public void setPlanAmountRange(String planAmountRange) {
		this.planAmountRange = planAmountRange;
	}

	public String getSpecialistWithoutReference() {
		return specialistWithoutReference;
	}

	public void setSpecialistWithoutReference(String specialistWithoutReference) {
		this.specialistWithoutReference = specialistWithoutReference;
	}

	public String getPreferHSA() {
		return preferHSA;
	}

	public void setPreferHSA(String preferHSA) {
		this.preferHSA = preferHSA;
	}

	public Set<Plan> getRecommendedPlans() {
		return recommendedPlans;
	}

	public void setRecommendedPlans(Set<Plan> recommendedPlans) {
		this.recommendedPlans = recommendedPlans;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		     
		sb.append("[<Zip Code:").append(zipCode).append(";")
		.append("[").append("Members:").append(members).append("]")
		.append("Eligible for Tax:").append(eligibleForTax).append(";")
		.append("Recent Life Change :").append(recentLifeEvent).append(";")
		.append("Recent Life Change Date:").append(recentLifeEventDate).append(";")
		.append("Medical Coverage:").append(medicalCoverageExists).append(";")
		.append("Plan Preference:").append(planPreference).append(";")
		.append("Plan Amount Range:").append(planAmountRange).append(";")
		.append("Specialist Without Reference:").append(specialistWithoutReference).append(";")
		.append("Prefer HSA:").append(preferHSA).append(";")
		.append("[").append("Recommended Plans:").append(recommendedPlans).append("]").append("]");
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Profile)){
			return false;
		}
		Profile c=(Profile)obj;
		boolean isEqual = this.zipCode.equals(c.getZipCode());
		isEqual = isEqual && this.members.equals(c.getMembers());
		isEqual = isEqual && this.eligibleForTax.equals(c.getEligibleForTax());
		isEqual = isEqual && this.recentLifeEvent.equals(c.getRecentLifeEvent());
		isEqual = isEqual && this.recentLifeEventDate.equals(c.getRecentLifeEventDate());
		isEqual = isEqual && this.medicalCoverageExists.equals(c.getMedicalCoverageExists());
		isEqual = isEqual && this.planPreference.equals(c.getPlanPreference());
		isEqual = isEqual && this.planAmountRange.equals(c.getPlanAmountRange());
		isEqual = isEqual && this.specialistWithoutReference.equals(c.getSpecialistWithoutReference());
		isEqual = isEqual && this.preferHSA.equals(c.getPreferHSA());
		isEqual = isEqual && this.recommendedPlans.equals(c.getRecommendedPlans());
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31;
		r *= this.zipCode.hashCode();
		r *= this.members.hashCode();
		r *= this.recentLifeEvent.hashCode();
		r *= this.recentLifeEventDate.hashCode();
		r *= this.medicalCoverageExists.hashCode();
		r *= this.planPreference.hashCode();
		r *= this.planAmountRange.hashCode();
		r *= this.specialistWithoutReference.hashCode();
		r *= this.preferHSA.hashCode();
		r *= this.recommendedPlans.hashCode();
		return r;
	}

	
}
