package com.connecture.bigbear.ancillary.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Member {
private String name;
private Date dateOfBirth;
private String relationShip;
private String smoking;
private String healthCareMonitor;
private List<Drug> drugs;
private boolean adult;
public Member(){
	name="";
	dateOfBirth=new Date();
	relationShip="";
	smoking="";
	healthCareMonitor="";
	drugs=new ArrayList<Drug>();
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getRelationShip() {
	return relationShip;
}
public void setRelationShip(String relationShip) {
	this.relationShip = relationShip;
}
 
public String getHealthCareMonitor() {
	return healthCareMonitor;
}
public void setHealthCareMonitor(String healthCareMonitor) {
	this.healthCareMonitor = healthCareMonitor;
}
public List<Drug> getDrugs() {
	return drugs;
}
public void setDrugs(List<Drug> drugs) {
	this.drugs = drugs;
}
public String getSmoking() {
	return smoking;
}
public void setSmoking(String smoking) {
	this.smoking = smoking;
}
 

public boolean isAdult() {
	return adult;
}

public void setAdult(boolean adult) {
	this.adult = adult;
}

@Override
public String toString() {
	StringBuilder sb = new StringBuilder();
	sb.append("[Name:").append(name).append(";")
	.append("Date Of Birth:").append(dateOfBirth).append(";")
	.append("Relation:").append(relationShip).append(";")
	.append("Smoking:").append(smoking).append(";")
	.append("Health Care Monitor:").append(healthCareMonitor).append(";")
	.append("Drugs:").append(drugs).append(";").append("]");
	return sb.toString();
}
@Override
public boolean equals(Object obj) {
	if(!(obj instanceof Member)){
		return false;
	}
	Member m=(Member)obj;
	boolean isEqual = this.name.equals(m.getName());
	isEqual = isEqual && this.dateOfBirth.equals(m.getDateOfBirth());
	isEqual = isEqual && this.relationShip.equals(m.getRelationShip());
	 
	return isEqual;
}
@Override
public int hashCode() {
	int r = 31;
	r *= this.name.hashCode();
	r *= this.dateOfBirth.hashCode();
	r *= this.relationShip.hashCode();
	r *= this.smoking.hashCode();
	r *= this.healthCareMonitor.hashCode();
	r *= this.drugs.hashCode();
	return r;
}

}
