package com.connecture.bigbear.ancillary.model;

public class Drug {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	} 
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[Name:").append(name).append(";").append("]");
		return sb.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if(!(obj instanceof Drug)){
			return false;
		}
		Drug d=(Drug)obj;
		boolean isEqual = this.name.equals(d.getName());
		 
		return isEqual;
	}
	@Override
	public int hashCode() {
		int r = 31;
		r *= this.name.hashCode(); 
		return r;
	}
}
