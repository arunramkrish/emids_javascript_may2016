package com.connecture.bigbear.ancillary.rules.process;

import java.util.Map;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.StatelessKieSession;

import com.connecture.bigbear.ancillary.exception.ShoppingException;
import com.connecture.bigbear.ancillary.session.StatefulSession;
import com.connecture.bigbear.ancillary.session.StatelessSession;
import com.connecture.bigbear.ancillary.util.LogHandler;

public abstract class RuleExecutor {
	private  Map<String,Object> result;
	private Map<String,Object> global;
	protected LogHandler log = null;
	protected String sessionName;
	protected StatelessKieSession getStateLess(String sessionName){
		StatelessSession session = new StatelessSession();
		log = StatelessSession.getLogHandler();
		return session.getStateLess(sessionName);
	}
	protected KieSession getStatefulSession(String sessionName){
		StatefulSession session = new StatefulSession();
		log = StatelessSession.getLogHandler();
		return session.getSession(sessionName);
	}
	 
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public Map<String,Object> getGlobal() {
		return global;
	}
	public void setGlobal(Map<String,Object> global) {
		this.global = global;
	}
	public Map<String,Object> getResult() {
		return result;
	}
	public void setResult(Map<String,Object> result) {
		this.result = result;
	}
	public abstract void execute(Object[]facts) throws ShoppingException;
}
