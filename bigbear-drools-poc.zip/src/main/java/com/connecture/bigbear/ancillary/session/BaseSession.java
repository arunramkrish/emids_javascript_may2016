package com.connecture.bigbear.ancillary.session;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;

import com.connecture.bigbear.ancillary.util.LogHandler;
 

public class BaseSession{
	protected static final LogHandler log = LogHandler.get(BaseSession.class);
	protected KieContainer kContainer = KieServices.Factory.get().getKieClasspathContainer();
	 
	public static LogHandler getLogHandler(){
		 return log;
	}
	public static void logMessage(String m){
		log.info(m);
	}
	
}
