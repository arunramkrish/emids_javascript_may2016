package com.connecture.bigbear.ancillary.json.util;

import java.io.IOException;
import java.util.Set;

import com.connecture.bigbear.ancillary.model.Plan;
import com.connecture.bigbear.ancillary.model.Profile;
import com.connecture.bigbear.ancillary.util.LogUtil;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
public class Json2Pojo { 
 
	public static Set<Profile> getProfile(String content) {
		ObjectMapper mapper = new ObjectMapper();
		Set<Profile> p = null;
		try {
			 p = mapper.readValue(content, TypeFactory.defaultInstance().constructCollectionType(Set.class,  
					 Profile.class));
		} catch (JsonGenerationException e) { 
			e.printStackTrace();
		} catch (JsonMappingException e) { 
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		LogUtil.logInfo("==================Profile=============================");
		LogUtil.logInfo(p.toString());
		return p;
	}
 
	public static Set<Plan> getPlan(String content) {
		ObjectMapper mapper = new ObjectMapper();
		Set<Plan> p = null;
		try {
			 p =  mapper.readValue(content, TypeFactory.defaultInstance().constructCollectionType(Set.class,  
					   Plan.class));
		} catch (JsonGenerationException e) { 
			e.printStackTrace();
		} catch (JsonMappingException e) { 
			e.printStackTrace();
		} catch (IOException e) { 
			e.printStackTrace();
		}
		LogUtil.logInfo("=================Plans==============================");
		LogUtil.logInfo(p.toString());
		return p; 
	}  
}
