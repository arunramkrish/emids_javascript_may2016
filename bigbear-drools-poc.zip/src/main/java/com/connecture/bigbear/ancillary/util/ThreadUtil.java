package com.connecture.bigbear.ancillary.util;

public class ThreadUtil {

	public static void sleepQuietly(long millis) {

		try {
			
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			//  Nothing Ignore
		}
	}
}
