package com.connecture.bigbear.ancillary.exception;

public class ShoppingException extends RuntimeException{
 
	private static final long serialVersionUID = 4028519366397778797L;
	 
	public ShoppingException(Throwable t) {
		 super(t);
	}
	 
}
