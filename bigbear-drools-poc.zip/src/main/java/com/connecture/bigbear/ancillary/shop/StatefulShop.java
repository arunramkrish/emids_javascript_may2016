package com.connecture.bigbear.ancillary.shop;

import com.connecture.bigbear.ancillary.constants.ShoppingAgenda;
import com.connecture.bigbear.ancillary.rules.process.StatefulRuleExecutor;

public class StatefulShop extends Shop { 
 
	protected void doExecute(Object[] facts,boolean multiple) {
		doExecute(facts, ""); 
		String session = "StatefulShopKS"; 
		if(multiple){
			session = "MStatefulShopKS";
		}
		doExecute(facts, session);
	}

	private void doExecute(Object[] facts, String session) {
		log.info(session+"@StatelessShopping execute Started ");
		try { 
			StatefulRuleExecutor executor = new StatefulRuleExecutor(ShoppingAgenda.names(),session);
			super.setExecutor(executor);
			executor.setGlobal(getGlobal() );
			executor.execute(facts); 
		} catch (Exception e) { 
			log.error(session+"@StatelessShopping execute ", e);
		}
	} 
}
